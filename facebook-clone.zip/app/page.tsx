import { Bell, Home, Menu, MessageSquare, Search, Users, Video } from "lucide-react"
import Image from "next/image"
import Link from "next/link"

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Separator } from "@/components/ui/separator"

export default function FacebookClone() {
  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <header className="sticky top-0 z-50 bg-white shadow">
        <div className="flex items-center justify-between p-2 mx-auto max-w-7xl">
          <div className="flex items-center">
            <Link href="/" className="flex items-center">
              <div className="w-10 h-10 mr-2 overflow-hidden rounded-full bg-blue-600">
                <span className="flex items-center justify-center w-full h-full text-2xl font-bold text-white">f</span>
              </div>
            </Link>
            <div className="relative ml-2">
              <Search className="absolute w-4 h-4 text-gray-400 transform -translate-y-1/2 left-3 top-1/2" />
              <Input
                type="text"
                placeholder="Search Facebook"
                className="w-64 pl-10 bg-gray-100 border-none rounded-full focus:bg-white"
              />
            </div>
          </div>

          <nav className="hidden md:flex">
            <Button variant="ghost" size="lg" className="relative px-10">
              <Home className="w-6 h-6" />
              <span className="absolute bottom-0 w-full h-1 bg-blue-600"></span>
            </Button>
            <Button variant="ghost" size="lg" className="px-10">
              <Video className="w-6 h-6" />
            </Button>
            <Button variant="ghost" size="lg" className="px-10">
              <Users className="w-6 h-6" />
            </Button>
          </nav>

          <div className="flex items-center space-x-2">
            <Button variant="ghost" size="icon" className="rounded-full bg-gray-200">
              <Menu className="w-5 h-5" />
            </Button>
            <Button variant="ghost" size="icon" className="rounded-full bg-gray-200">
              <MessageSquare className="w-5 h-5" />
            </Button>
            <Button variant="ghost" size="icon" className="rounded-full bg-gray-200">
              <Bell className="w-5 h-5" />
            </Button>
            <Avatar>
              <AvatarImage src="/placeholder.svg?height=40&width=40" alt="User" />
              <AvatarFallback>UN</AvatarFallback>
            </Avatar>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="py-4 mx-auto max-w-7xl">
        <div className="grid grid-cols-1 gap-4 px-4 md:grid-cols-3 lg:grid-cols-4">
          {/* Left Sidebar */}
          <div className="hidden md:block">
            <nav className="space-y-1">
              <Link href="#" className="flex items-center p-2 space-x-2 rounded-lg hover:bg-gray-200">
                <Avatar>
                  <AvatarImage src="/placeholder.svg?height=36&width=36" alt="User" />
                  <AvatarFallback>UN</AvatarFallback>
                </Avatar>
                <span className="font-medium">Your Name</span>
              </Link>
              <Link href="#" className="flex items-center p-2 space-x-2 rounded-lg hover:bg-gray-200">
                <Users className="w-8 h-8 p-1 text-white bg-blue-600 rounded-full" />
                <span>Friends</span>
              </Link>
              <Link href="#" className="flex items-center p-2 space-x-2 rounded-lg hover:bg-gray-200">
                <Users className="w-8 h-8 p-1 text-blue-600 bg-gray-200 rounded-full" />
                <span>Groups</span>
              </Link>
              <Link href="#" className="flex items-center p-2 space-x-2 rounded-lg hover:bg-gray-200">
                <Video className="w-8 h-8 p-1 text-blue-600 bg-gray-200 rounded-full" />
                <span>Watch</span>
              </Link>
              <Link href="#" className="flex items-center p-2 space-x-2 rounded-lg hover:bg-gray-200">
                <span className="flex items-center justify-center w-8 h-8 text-blue-600 bg-gray-200 rounded-full">
                  M
                </span>
                <span>Marketplace</span>
              </Link>
            </nav>
          </div>

          {/* News Feed */}
          <div className="space-y-4 md:col-span-2">
            {/* Create Post */}
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center space-x-2">
                  <Avatar>
                    <AvatarImage src="/placeholder.svg?height=40&width=40" alt="User" />
                    <AvatarFallback>UN</AvatarFallback>
                  </Avatar>
                  <Input placeholder="What's on your mind?" className="bg-gray-100 rounded-full" />
                </div>
                <Separator className="my-4" />
                <div className="flex justify-between">
                  <Button variant="ghost" className="flex-1 text-gray-500">
                    <Video className="w-5 h-5 mr-2 text-red-500" />
                    Live Video
                  </Button>
                  <Button variant="ghost" className="flex-1 text-gray-500">
                    <Image src="/placeholder.svg?height=20&width=20" width={20} height={20} alt="" className="mr-2" />
                    Photo/Video
                  </Button>
                  <Button variant="ghost" className="flex-1 text-gray-500">
                    <span className="mr-2 text-yellow-500">😊</span>
                    Feeling/Activity
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Posts */}
            <Card>
              <CardHeader className="p-4 pb-0">
                <div className="flex items-center space-x-2">
                  <Avatar>
                    <AvatarImage src="/placeholder.svg?height=40&width=40" alt="Jane Doe" />
                    <AvatarFallback>JD</AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-semibold">Jane Doe</p>
                    <p className="text-xs text-gray-500">2 hours ago</p>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-4">
                <p>Just finished my new painting! What do you think? 🎨</p>
                <div className="mt-3 overflow-hidden rounded-lg">
                  <Image
                    src="/placeholder.svg?height=400&width=600"
                    width={600}
                    height={400}
                    alt="Painting"
                    className="w-full"
                  />
                </div>
              </CardContent>
              <CardFooter className="p-4 pt-0">
                <div className="w-full">
                  <div className="flex items-center justify-between mb-2 text-sm text-gray-500">
                    <div className="flex items-center">
                      <div className="flex items-center justify-center w-5 h-5 mr-1 text-white bg-blue-600 rounded-full">
                        👍
                      </div>
                      <span>87 likes</span>
                    </div>
                    <div>24 comments</div>
                  </div>
                  <Separator />
                  <div className="flex justify-between mt-2">
                    <Button variant="ghost" className="flex-1 text-gray-500">
                      👍 Like
                    </Button>
                    <Button variant="ghost" className="flex-1 text-gray-500">
                      💬 Comment
                    </Button>
                    <Button variant="ghost" className="flex-1 text-gray-500">
                      ↪️ Share
                    </Button>
                  </div>
                </div>
              </CardFooter>
            </Card>

            <Card>
              <CardHeader className="p-4 pb-0">
                <div className="flex items-center space-x-2">
                  <Avatar>
                    <AvatarImage src="/placeholder.svg?height=40&width=40" alt="John Smith" />
                    <AvatarFallback>JS</AvatarFallback>
                  </Avatar>
                  <div>
                    <p className="font-semibold">John Smith</p>
                    <p className="text-xs text-gray-500">5 hours ago</p>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-4">
                <p>
                  Just got back from an amazing trip to the mountains! The views were breathtaking and the weather was
                  perfect. Can't wait to go back! 🏔️
                </p>
                <div className="grid grid-cols-2 gap-1 mt-3">
                  <Image
                    src="/placeholder.svg?height=200&width=200"
                    width={200}
                    height={200}
                    alt="Mountain view 1"
                    className="w-full rounded-tl-lg"
                  />
                  <Image
                    src="/placeholder.svg?height=200&width=200"
                    width={200}
                    height={200}
                    alt="Mountain view 2"
                    className="w-full rounded-tr-lg"
                  />
                  <Image
                    src="/placeholder.svg?height=200&width=200"
                    width={200}
                    height={200}
                    alt="Mountain view 3"
                    className="w-full rounded-bl-lg"
                  />
                  <Image
                    src="/placeholder.svg?height=200&width=200"
                    width={200}
                    height={200}
                    alt="Mountain view 4"
                    className="w-full rounded-br-lg"
                  />
                </div>
              </CardContent>
              <CardFooter className="p-4 pt-0">
                <div className="w-full">
                  <div className="flex items-center justify-between mb-2 text-sm text-gray-500">
                    <div className="flex items-center">
                      <div className="flex items-center justify-center w-5 h-5 mr-1 text-white bg-blue-600 rounded-full">
                        👍
                      </div>
                      <span>142 likes</span>
                    </div>
                    <div>36 comments</div>
                  </div>
                  <Separator />
                  <div className="flex justify-between mt-2">
                    <Button variant="ghost" className="flex-1 text-gray-500">
                      👍 Like
                    </Button>
                    <Button variant="ghost" className="flex-1 text-gray-500">
                      💬 Comment
                    </Button>
                    <Button variant="ghost" className="flex-1 text-gray-500">
                      ↪️ Share
                    </Button>
                  </div>
                </div>
              </CardFooter>
            </Card>
          </div>

          {/* Right Sidebar */}
          <div className="hidden lg:block">
            <Card>
              <CardHeader className="pb-2">
                <h3 className="text-lg font-semibold">Sponsored</h3>
              </CardHeader>
              <CardContent className="p-4">
                <div className="space-y-4">
                  <div className="space-y-2">
                    <div className="overflow-hidden rounded-lg">
                      <Image
                        src="/placeholder.svg?height=120&width=240"
                        width={240}
                        height={120}
                        alt="Advertisement"
                        className="w-full"
                      />
                    </div>
                    <div className="flex justify-between">
                      <div>
                        <p className="font-medium">Summer Sale</p>
                        <p className="text-xs text-gray-500">example.com</p>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="mt-4">
              <CardHeader className="pb-2">
                <h3 className="text-lg font-semibold">Contacts</h3>
              </CardHeader>
              <CardContent className="p-4">
                <div className="space-y-2">
                  <div className="flex items-center space-x-2">
                    <div className="relative">
                      <Avatar>
                        <AvatarImage src="/placeholder.svg?height=36&width=36" alt="Sarah Johnson" />
                        <AvatarFallback>SJ</AvatarFallback>
                      </Avatar>
                      <span className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 border-2 border-white rounded-full"></span>
                    </div>
                    <span>Sarah Johnson</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="relative">
                      <Avatar>
                        <AvatarImage src="/placeholder.svg?height=36&width=36" alt="Mike Williams" />
                        <AvatarFallback>MW</AvatarFallback>
                      </Avatar>
                      <span className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 border-2 border-white rounded-full"></span>
                    </div>
                    <span>Mike Williams</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="relative">
                      <Avatar>
                        <AvatarImage src="/placeholder.svg?height=36&width=36" alt="Emily Davis" />
                        <AvatarFallback>ED</AvatarFallback>
                      </Avatar>
                    </div>
                    <span>Emily Davis</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="relative">
                      <Avatar>
                        <AvatarImage src="/placeholder.svg?height=36&width=36" alt="Alex Thompson" />
                        <AvatarFallback>AT</AvatarFallback>
                      </Avatar>
                      <span className="absolute bottom-0 right-0 w-3 h-3 bg-green-500 border-2 border-white rounded-full"></span>
                    </div>
                    <span>Alex Thompson</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="relative">
                      <Avatar>
                        <AvatarImage src="/placeholder.svg?height=36&width=36" alt="Lisa Brown" />
                        <AvatarFallback>LB</AvatarFallback>
                      </Avatar>
                    </div>
                    <span>Lisa Brown</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  )
}

